# Azure Function Deployment Script
# Deploys OrderProcessor to cloOrchestratorFunction - One Deploy

param(
    [Parameter(Mandatory=$true)]
    [string]$FunctionAppName = "cloOrchestratorFunction - One Deploy",

    [Parameter(Mandatory=$true)]
    [string]$ResourceGroupName = "rg-clo-document-intelligence",

    [Parameter(Mandatory=$false)]
    [string]$PublishPath = "./bin/Release/net8.0/publish"
)

# Colors for output
$Success = @{ ForegroundColor = 'Green' }
$Error = @{ ForegroundColor = 'Red' }
$Info = @{ ForegroundColor = 'Cyan' }

Write-Host "Azure Function Deployment Script" @Info
Write-Host "=================================" @Info
Write-Host "Function App: $FunctionAppName" @Info
Write-Host "Resource Group: $ResourceGroupName" @Info
Write-Host "Publish Path: $PublishPath" @Info
Write-Host ""

# Step 1: Build the project
Write-Host "Step 1: Building project..." @Info
dotnet build -c Release
if ($LASTEXITCODE -ne 0) {
    Write-Host "Build failed!" @Error
    exit 1
}
Write-Host "Build successful!" @Success

# Step 2: Publish the project
Write-Host "Step 2: Publishing project..." @Info
dotnet publish -c Release -o $PublishPath --self-contained false
if ($LASTEXITCODE -ne 0) {
    Write-Host "Publish failed!" @Error
    exit 1
}
Write-Host "Publish successful!" @Success

# Step 3: Deploy to Azure
Write-Host "Step 3: Deploying to Azure..." @Info
Write-Host "Note: Requires Azure CLI installed and authenticated" @Info
Write-Host ""

# Check if func CLI exists
$funcPath = Get-Command func -ErrorAction SilentlyContinue
if (-not $funcPath) {
    Write-Host "Azure Functions Core Tools (func CLI) not found." @Error
    Write-Host "Install from: https://learn.microsoft.com/azure/azure-functions/functions-run-local" @Error
    Write-Host ""
    Write-Host "Alternative: Deploy using Azure Portal" @Info
    Write-Host "1. Go to Azure Portal > Function App > Deployment center" @Info
    Write-Host "2. Connect your repository or upload the publish folder" @Info
    Write-Host "3. Click Deploy" @Info
    exit 1
}

# Deploy using func CLI
Write-Host "Deploying with func CLI..." @Info
func azure functionapp publish "$FunctionAppName" --build remote

if ($LASTEXITCODE -eq 0) {
    Write-Host "Deployment successful!" @Success
    Write-Host ""
    Write-Host "Your Azure Function is now deployed!" @Success
} else {
    Write-Host "Deployment failed!" @Error
    Write-Host "Check the error messages above for details" @Error
    exit 1
}
