using Microsoft.Azure.Functions.Worker;
using Microsoft.Azure.Functions.Worker.Http;
using Microsoft.DurableTask;
using Microsoft.DurableTask.Client;
using Microsoft.Extensions.Logging;
using Company.Function.Models;
using Company.Function.Activities;


namespace Company.Function
{
    public static class OrderProcessingOrchestration
    {
        [Function(nameof(OrderProcessingOrchestration))]
        public static async Task<OrderResult> RunOrchestrator(
            [OrchestrationTrigger] TaskOrchestrationContext context, OrderPayload order)
        {
            ILogger logger = context.CreateReplaySafeLogger(nameof(OrderProcessingOrchestration));
          
            // Determine if there is enough of the item available for purchase by checking the inventory
            string orderId = context.InstanceId;
            logger.LogInformation("Started processing order {orderId}", orderId);
            InventoryResult result = await context.CallActivityAsync<InventoryResult>(
                nameof(Activities.ReserveInventory), 
                new InventoryRequest(RequestId: orderId, order.Name, order.Quantity));
            
            if (!result.Success)
            {
                await context.CallActivityAsync(
                    nameof(Activities.NotifyCustomer),
                    new Notification($"Insufficient inventory for {order.Name}"));
                return new OrderResult(Processed: false);
            }

            await context.CallActivityAsync(
                nameof(Activities.ProcessPayment),
                new PaymentRequest(RequestId: orderId, order.Name, order.Quantity, order.TotalCost));

            try
            {
                await context.CallActivityAsync<object?>(
                    nameof(Activities.UpdateInventory),
                    new InventoryRequest(RequestId: orderId, order.Name, order.Quantity));
            }
            catch (TaskFailedException)
            {
                await context.CallActivityAsync<object?>(
                    nameof(Activities.NotifyCustomer),
                    new Notification($"Order {orderId} Failed! You are now getting a refund"));
                return new OrderResult(Processed: false);
            }

            await context.CallActivityAsync<object?>(
                nameof(Activities.NotifyCustomer),
                new Notification($"Order {orderId} has completed!"));

    
            return new OrderResult(Processed: true);
        }
        [Function("OrderProcessingOrchestration_BlobStart")]
        public static async Task BlobStart(
            [BlobTrigger(
        "input/{name}",
        Connection = "AzureWebJobsStorage")]
    Stream blobStream,
            string name,
            [DurableClient] DurableTaskClient client,
            FunctionContext executionContext)
        {
            ILogger logger =
                executionContext.GetLogger("OrderProcessingOrchestration_BlobStart");

            logger.LogInformation(
                "Blob triggered: {BlobName}",
                name);

            try
            {
                // For now, create the same test order as the HTTP trigger
                var order = new OrderPayload(
                    "milk",
                    TotalCost: 5,
                    Quantity: 1);

                string instanceId =
                    await client.ScheduleNewOrchestrationInstanceAsync(
                        nameof(OrderProcessingOrchestration),
                        order);

                logger.LogInformation(
                    "Started orchestration with ID = '{InstanceId}' for blob '{BlobName}'.",
                    instanceId,
                    name);
            }
            catch (Exception ex)
            {
                logger.LogError(
                    ex,
                    "Error processing blob: {BlobName}",
                    name);

                throw;
            }
        }
    }
}
